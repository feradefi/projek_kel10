<?php

include 'functions.php';
include 'templateadmin/header.php';
include 'templateadmin/sidebar.php';

$mobil = index("SELECT * FROM mobil_sering_disewa_perbulan");
$transaksi = index("SELECT * FROM vw_detail_penyewaan ORDER BY id_transaksi DESC LIMIT 10");

date_default_timezone_set('Asia/Jakarta');
$bulanAngka = date('n');
$bulan = array(
    1 => 'Januari',
    2 => 'Februari',
    3 => 'Maret',
    4 => 'April',
    5 => 'Mei',
    6 => 'Juni',
    7 => 'Juli',
    8 => 'Agustus',
    9 => 'September',
    10 => 'Oktober',
    11 => 'November',
    12 => 'Desember'
);
$bulanNow = $bulan[$bulanAngka];

$user_query = "SELECT COUNT(*) AS total_users FROM users WHERE role='User'";
$user_result = $conn->query($user_query);
$user_data = $user_result->fetch_assoc();
$total_users = $user_data['total_users'];

// Query untuk menghitung total mobil
$car_query = "SELECT COUNT(*) AS total_cars FROM mobil";
$car_result = $conn->query($car_query);
$car_data = $car_result->fetch_assoc();
$total_cars = $car_data['total_cars'];

// Query untuk menghitung total transaksi
$transaction_query = "SELECT COUNT(*) AS total_transactions FROM transaksi";
$transaction_result = $conn->query($transaction_query);
$transaction_data = $transaction_result->fetch_assoc();
$total_transactions = $transaction_data['total_transactions'];
?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Dashboard</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="row">

            <!-- Sales Card -->
            <div class=" col-md-4">
                <div class="card info-card sales-card">

                    <div class="card-body">
                        <h5 class="card-title">Mobil</h5>

                        <div class="d-flex align-items-center">
                            <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-car-front-fill"></i>
                            </div>
                            <div class="ps-3">
                                <h6><?= $total_cars ?></h6>
                                <span class="text-muted small pt-2 ps-1">unit</span>

                            </div>
                        </div>
                    </div>

                </div>
            </div><!-- End Sales Card -->

            <!-- Revenue Card -->
            <div class=" col-md-4">
                <div class="card info-card revenue-card">

                    <div class="card-body">
                        <h5 class="card-title">Penyewaan </h5>

                        <div class="d-flex align-items-center">
                            <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-currency-dollar"></i>
                            </div>
                            <div class="ps-3">
                                <h6><?= $total_transactions ?></h6>
                                <span class="text-muted small pt-2 ps-1">kali</span>

                            </div>
                        </div>
                    </div>

                </div>
            </div><!-- End Revenue Card -->

            <!-- Customers Card -->
            <div class=" col-xl-4">

                <div class="card info-card customers-card">
                    <div class="card-body">
                        <h5 class="card-title">Customers </h5>

                        <div class="d-flex align-items-center">
                            <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-people"></i>
                            </div>
                            <div class="ps-3">
                                <h6><?= $total_users ?></h6>
                                <span class="text-muted small pt-2 ps-1">orang</span>

                            </div>
                        </div>

                    </div>
                </div>

            </div><!-- End Customers Card -->

            <!-- Recent Sales -->
            <div class="col-12">
                <div class="card recent-sales overflow-auto">

                    <div class="card-body">
                        <h5 class="card-title">Transaksi <span>| 10 Transaksi Terakhir</span></h5>

                        <table class="table table-borderless">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Customer</th>
                                    <th scope="col">Mobil</th>
                                    <th scope="col">Total Biaya</th>
                                    <th scope="col">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($transaksi as $trs) : ?>
                                    <tr>
                                        <th scope="row"><a href="#"><?= $trs['id_transaksi'] ?></a></th>
                                        <td><?= $trs['nama'] ?></td>
                                        <td><a href="#" class="text-primary"><?= $trs['merk'], $trs['model'] ?></a></td>
                                        <td><?= $trs['total_biaya'] ?></td>
                                        <?php if ($trs['status_transaksi'] == "Belum Selesai") : ?>
                                            <td><span class="badge bg-danger"><?= $trs['status_transaksi'] ?></span></td>
                                        <?php elseif ($trs['status_transaksi'] == "Selesai") : ?>
                                            <td><span class="badge bg-success"><?= $trs['status_transaksi'] ?></span></td>
                                        <?php elseif ($trs['status_transaksi'] == "Pending") : ?>
                                            <td><span class="badge bg-warning"><?= $trs['status_transaksi'] ?></span></td>
                                        <?php elseif ($trs['status_transaksi'] == "Belum Bayar") : ?>
                                            <td><span class="badge bg-info"><?= $trs['status_transaksi'] ?></span></td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>

                    </div>

                </div>
            </div><!-- End Recent Sales -->

            <!-- Top Selling -->
            <div class="col-12">
                <div class="card top-selling overflow-auto">
                    <div class="card-body pb-0">
                        <h5 class="card-title">Mobil Ter Favorit <span>| Bulan <?= $bulanNow ?></span></h5>

                        <table class="table table-borderless">
                            <thead>
                                <tr>
                                    <th scope="col">ID Mobil</th>
                                    <th scope="col">Merk</th>
                                    <th scope="col">Model</th>
                                    <th scope="col">Tahun</th>
                                    <th scope="col">Warna</th>
                                    <th scope="col">Total Penyewaan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($mobil as $mbl) : ?>
                                    <tr>
                                        <th scope="row"><?= $mbl['id_mobil'] ?></th>
                                        <td><a href="detailmobil.php?id=<?= $mbl['id_mobil'] ?>" class="text-primary fw-bold"><?= $mbl['merk'] ?></a></td>
                                        <td><?= $mbl['model'] ?></td>
                                        <td><?= $mbl['tahun'] ?></td>
                                        <td><?= $mbl['warna'] ?></td>
                                        <td class="fw-bold"><?= $mbl['jumlah_penyewaan'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>

                    </div>

                </div>
            </div><!-- End Top Selling -->

        </div>
    </section>

</main><!-- End #main -->

<?php

include 'templateadmin/footer.php';
?>