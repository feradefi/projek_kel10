<?php

require 'functions.php';
include 'templateadmin/header.php';
include 'templateadmin/sidebar.php';

$transaksi = index("SELECT * FROM riwayat_perawatan");
?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>History Perawatan</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">History Perawatan</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">History Perawatan</h5>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                <th>Id</th>
                                    <th>Nama Pengguna</th>
                                    <th>No Telepon</th>
                                    <th>Merk Mobil</th>
                                    <th>Model</th>
                                    <th>Tanggal Perawatan</th>
                                    <th>Deskripsi Perawatan</th>
                                    <th>Biaya Perawatan</th>
                                    <th>Status Perawatan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                foreach ($transaksi as $adm) :
                                ?>
                                    <tr>
                                    <td><?= $adm['id_perawatan'] ?></td>
                                        <td><?= $adm['nama_pengguna'] ?></td>
                                        <td><?= $adm['no_telepon'] ?></td>
                                        <td><?= $adm['merk'] ?></td>
                                        <td><?= $adm['model'] ?></td>
                                        <td><?= $adm['tanggal'] ?></td>
                                        <td><?= $adm['deskripsi'] ?></td>
                                        <td><?= $adm['biaya'] ?></td>
                                        <td><?= $adm['status_perawatan'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include 'templateadmin/footer.php';
?>