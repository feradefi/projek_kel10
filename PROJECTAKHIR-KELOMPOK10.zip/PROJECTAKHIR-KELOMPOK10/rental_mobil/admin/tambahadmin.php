<?php

require 'functions.php';
include '../template/header.php';
include '../template/sidebar.php';
if (isset($_POST['submit'])) {
    if (tambah($_POST) > 0) {
        echo "<script>alert('Data admin Berhasil ditambahkan');document.location.href='admin.php';</script>";
    } else {
        echo "<script>alert('Data admin Gagal ditambahkan');";
    }
}
?>


<main id="main" class="main">

    <div class="pagetitle">
        <h1>Data Admin</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">Administrator</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Tabel Administrator</h5>

                        <!-- No Labels Form -->
                        <form class="row g-3" action="" method="post" enctype="multipart/form-data">
                            <div class="col-md-12">
                                <input type="text" name="nama" class="form-control" placeholder="Masukkan nama">
                            </div>
                            <div class="col-md-6">
                                <input type="email" class="form-control" name="email" placeholder="Email">
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="no_telepon" placeholder="Nomor Telepon">
                            </div>
                            <div class="col-12">
                                <input type="text" name="alamat" class="form-control" placeholder="Alamat">
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="username" class="form-control" placeholder="Masukkan username">
                            </div>
                            <div class="col-md-6">
                                <input type="password" class="form-control" placeholder="Password">
                            </div>
                            <div class="col-md-12">
                                <input type="file" name="foto" class="form-control">
                            </div>
                            <div class="text-center">
                                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                <button type="reset" class="btn btn-secondary">Reset</button>
                            </div>
                        </form><!-- End No Labels Form -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include '../template/footer.php';
?>