<?php
require 'functions.php';
include 'templateadmin/header.php';
include 'templateadmin/sidebar.php';

$history = index("SELECT * FROM riwayat_transaksi");
?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>History Transaksi</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">History Transaksi</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <a href="tambahadmin.php" class="btn btn-primary"><i class="bi bi-plus mb-5"></i> Tambah</a>

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">History Transaksi</h5>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nama</th>
                                    <th>Merk</th>
                                    <th>Model</th>
                                    <th>Tanggal Mulai</th>
                                    <th>Tanggal Selesai</th>
                                    <th>Status Transaksi</th>
                                    <th>Metode Pembayaran</th>
                                    <th>Status Pembayaran</th>
                                    <th>Denda</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                foreach ($history as $adm) :
                                ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><?= $adm['Nama Lengkap'] ?></td>
                                        <td><?= $adm['Merk Mobil'] ?></td>
                                        <td><?= $adm['Model Mobil'] ?></td>
                                        <td><?= $adm['Tanggal Mulai'] ?></td>
                                        <td><?= $adm['Tanggal Selesai'] ?></td>
                                        <td><?= $adm['Status Transaksi'] ?></td>
                                        <td><?= $adm['Metode Pembayaran'] ?></td>
                                        <td><?= $adm['Status Pembayaran'] ?></td>
                                        <td><?= $adm['Denda'] ?></td>
                                        <td><a href="detailhistorytransaksi.php?id=<?= $adm['ID Transaksi'] ?>" class="btn btn-info"><i class="bi bi-eye"></i></a></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include 'templateadmin/footer.php';
?>