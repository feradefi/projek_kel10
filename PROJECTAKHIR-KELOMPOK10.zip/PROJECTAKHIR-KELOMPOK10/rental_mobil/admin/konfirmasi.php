<?php
require 'functions.php';
$id = $_GET['id'];

if (konfirmasi($id) > 0) {
    echo "<script>alert('Data Berhasil Dikonfirmasi');document.location.href='transaksi.php';</script>";
} else {
    echo "<script>alert('Terjadi kesalahan saat Mengkonfirmasi');document.location.href='transaksi.php';</script>";
}
