<?php
require 'functions.php';
$id = $_GET['id'];

if (hapusmobil($id) > 0) {
    echo "<script>alert('Data Mobil Berhasil dihapus');document.location.href='mobil.php';</script>";
} else {
    echo "<script>alert('Terjadi kesalahan saat menghapus data');document.location.href='mobil.php';</script>";
}
