<?php

require 'functions.php';
include 'templateadmin/header.php';
include 'templateadmin/sidebar.php';

$mobil = index("SELECT * FROM mobil");
?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Data Mobil</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">mobil</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <a href="tambahmobil.php" class="btn btn-primary"><i class="bi bi-plus mb-5"></i> Tambah</a>

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Data Mobil</h5>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        <b>N</b>o
                                    </th>
                                    <th>Merk</th>
                                    <th>Model</th>
                                    <th>Tahun</th>
                                    <th>Warna</th>
                                    <th>Harga</th>
                                    <th>Status</th>
                                    <th>Gambar</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                foreach ($mobil as $mbl) :
                                ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><?= $mbl['merk'] ?></td>
                                        <td><?= $mbl['model'] ?></td>
                                        <td><?= $mbl['tahun'] ?></td>
                                        <td><?= $mbl['warna'] ?></td>
                                        <td><?= $mbl['harga_perhari'] ?></td>
                                        <td><?= $mbl['status'] ?></td>
                                        <td><img src="../assets/mobil/<?= $mbl['gambar'] ?>" style="width: 100px; height: 100px;" alt="foto"></td>
                                        <td><a href="editmobil.php?id=<?= $mbl['id_mobil'] ?>" class="btn btn-warning"><i class="bi bi-pencil-square"></i></a> <a href="hapusmobil.php?id=<?= $adm['id_mobil'] ?>" class="btn btn-danger"><i class="bi bi-trash"></i></a></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include 'templateadmin/footer.php';
?>