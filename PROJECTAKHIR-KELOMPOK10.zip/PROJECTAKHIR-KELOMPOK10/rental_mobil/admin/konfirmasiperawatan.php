<?php
require 'functions.php';
$id = $_GET['id'];

if (konfirmasiperawatan($id) > 0) {
    echo "<script>alert('Data perawatan Berhasil Dikonfirmasi');document.location.href='perawatan.php';</script>";
} else {
    echo "<script>alert('Terjadi kesalahan saat Mengkonfirmasi');document.location.href='perawatan.php';</script>";
}
