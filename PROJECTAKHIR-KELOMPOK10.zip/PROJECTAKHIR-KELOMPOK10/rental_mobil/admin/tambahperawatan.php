<?php

require 'functions.php';
include 'templateadmin/header.php';

$mobil = index("SELECT * FROM mobil");

if (isset($_POST['submit'])) {
    if (tambahperawatan($_POST) > 0) {
        echo "<script>alert('Data Perawatan Berhasil ditambahkan');document.location.href='perawatan.php';</script>";
    } else {
        echo "<script>alert('Data Perawatan Gagal ditambahkan');";
    }
}
?>


<main id="main" class="main">

    <div class="pagetitle">
        <h1>Tambah Perawatan</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item">Perawatan</li>
                <li class="breadcrumb-item active">Tambah Perawatan</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Tabel Mobil</h5>

                        <!-- No Labels Form -->
                        <form action="" method="post" enctype="multipart/form-data">
                            <div class="row mb-3">
                                <label for="inputText" class="col-sm-2 col-form-label">Mobil</label>
                                <div class="col-sm-10">
                                    <select name="id_mobil" id="" class="form-select">
                                        <?php foreach ($mobil as $mbl) : ?>
                                            <option value="<?= $mbl['id_mobil'] ?>"><?= $mbl['merk'] ?> <?= $mbl['model'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="inputDate" class="col-sm-2 col-form-label">Tanggal</label>
                                <div class="col-sm-10">
                                    <input type="date" name="tanggal" class="form-control">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="deskripsi" class="col-sm-2 col-form-label">Deskripsi</label>
                                <div class="col-sm-10">
                                    <input type="text" name="deskripsi" class="form-control">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="biaya" class="col-sm-2 col-form-label">Biaya</label>
                                <div class="col-sm-10">
                                    <input type="number" name="biaya" class="form-control">
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                <button type="reset" class="btn btn-secondary">Reset</button>
                            </div>
                            <input type="hidden" name="id_users" value="<?= $_SESSION['id_users'] ?>">
                        </form><!-- End No Labels Form -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include '../template/footer.php';
?>