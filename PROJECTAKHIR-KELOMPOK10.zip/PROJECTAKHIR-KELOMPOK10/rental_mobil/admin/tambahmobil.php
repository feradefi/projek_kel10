<?php

require 'functions.php';
include 'templateadmin/header.php';
include 'templateadmin/sidebar.php';
if (isset($_POST['submit'])) {
    if (tambahmobil($_POST) > 0) {
        echo "<script>alert('Data mobil Berhasil ditambahkan');document.location.href='mobil.php';</script>";
    } else {
        echo "<script>alert('Data mobil Gagal ditambahkan');";
    }
}
?>


<main id="main" class="main">

    <div class="pagetitle">
        <h1>Data Admin</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item">Mobil</li>
                <li class="breadcrumb-item active">Tambah Mobil</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Tabel Mobil</h5>

                        <!-- No Labels Form -->
                        <form class="row g-3" action="" method="post" enctype="multipart/form-data">
                            <div class="col-md-12">
                                <input type="text" name="merk" class="form-control" placeholder="Masukkan merk">
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="model" placeholder="Model">
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="tahun" placeholder="Tahun">
                            </div>
                            <div class="col-12">
                                <input type="text" name="warna" class="form-control" placeholder="Warna">
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="harga_perhari" class="form-control" placeholder="Masukkan harga">
                            </div>
                            <div class="col-md-12">
                                <input type="file" name="foto" class="form-control">
                            </div>
                            <div class="text-center">
                                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                <button type="reset" class="btn btn-secondary">Reset</button>
                            </div>
                        </form><!-- End No Labels Form -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include '../template/footer.php';
?>