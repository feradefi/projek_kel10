<?php

require 'functions.php';
include 'templateadmin/header.php';
include 'templateadmin/sidebar.php';

$mobil = index("SELECT * FROM log_hapus_mobil");
?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Data Mobil Terhapus</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">mobil terhapus</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Data Mobil Terhapus</h5>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        <b>N</b>o
                                    </th>
                                    <th>Merk</th>
                                    <th>Model</th>
                                    <th>Tahun</th>
                                    <th>Warna</th>
                                    <th>Harga</th>
                                    <th>Status</th>
                                    <th>Gambar</th>
                                    <th>Waktu Hapus</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                foreach ($mobil as $mbl) :
                                ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><?= $mbl['merk'] ?></td>
                                        <td><?= $mbl['model'] ?></td>
                                        <td><?= $mbl['tahun'] ?></td>
                                        <td><?= $mbl['warna'] ?></td>
                                        <td><?= $mbl['harga_perhari'] ?></td>
                                        <td><?= $mbl['status'] ?></td>
                                        <td><img src="../assets/mobil/<?= $mbl['gambar'] ?>" style="width: 100px; height: 100px;" alt="foto"></td>
                                        <td><?= $mbl['waktu_dihapus'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include 'templateadmin/footer.php';
?>