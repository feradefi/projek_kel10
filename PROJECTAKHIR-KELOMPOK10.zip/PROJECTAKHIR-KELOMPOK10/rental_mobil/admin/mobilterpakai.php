<?php

require '../admin/functions.php';
include 'templateadmin/header.php';
include 'templateadmin/sidebar.php';

$mobil_dipinjam = index("SELECT * FROM mobil_dipinjam_view");
?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Data Mobil Dipinjam</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">Data Mobil Dipinjam</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Data Admin</h5>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        <b>N</b>o
                                    </th>
                                    <th>Merk</th>
                                    <th>Model</th>
                                    <th>Tahun</th>
                                    <th>Warna</th>
                                    <th>Tanggal Mulai</th>
                                    <th>Tanggal Selesai</th>
                                    <th>Nama Pelanggan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                foreach ($mobil_dipinjam as $pjm) :
                                ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><?= $pjm['merk'] ?></td>
                                        <td><?= $pjm['model'] ?></td>
                                        <td><?= $pjm['tahun'] ?></td>
                                        <td><?= $pjm['warna'] ?></td>
                                        <td><?= $pjm['tanggal_mulai'] ?></td>
                                        <td><?= $pjm['tanggal_Selesai'] ?></td>
                                        <td><?= $pjm['nama_pelanggan'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include 'templateadmin/footer.php';
?>