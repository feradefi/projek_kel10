<?php
include '../koneksi.php';

function index($query)
{
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

function tambah($data)
{
    global $conn;
    $target_dir = "../assets/foto/";
    $target_file = $target_dir . basename($_FILES["foto"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Buat folder uploads jika belum ada
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0755, true);
    }

    // Pindahkan file ke direktori target
    if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
        echo "File " . htmlspecialchars(basename($_FILES["foto"]["name"])) . " telah diunggah.";
    } else {
        echo "Maaf, terjadi kesalahan saat mengunggah file Anda.";
    }
    $nama = htmlspecialchars($data['nama']);
    $email = htmlspecialchars($data['email']);
    $no_telepon = htmlspecialchars($data['no_telepon']);
    $username = htmlspecialchars($data['username']);
    $password = htmlspecialchars($data['password']);
    $role   = 'Admin';
    $alamat = htmlspecialchars($data['alamat']);
    $gambar = $_FILES["foto"]["name"];
    $sql = "INSERT INTO users (nama, email, no_telepon, username, password, role, alamat, gambar) VALUES ('$nama', '$email', '$no_telepon', '$username', '$password', '$role', '$alamat' , '$gambar')";
    mysqli_query($conn, $sql);

    return mysqli_affected_rows($conn);
}
function registrasi($data)
{
    global $conn;
    $target_dir = "../assets/foto/";
    $target_file = $target_dir . basename($_FILES["foto"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Buat folder uploads jika belum ada
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0755, true);
    }

    // Pindahkan file ke direktori target
    if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
        echo "File " . htmlspecialchars(basename($_FILES["foto"]["name"])) . " telah diunggah.";
    } else {
        echo "Maaf, terjadi kesalahan saat mengunggah file Anda.";
    }
    $nama = htmlspecialchars($data['nama']);
    $email = htmlspecialchars($data['email']);
    $no_telepon = htmlspecialchars($data['no_telepon']);
    $username = htmlspecialchars($data['username']);
    $password = htmlspecialchars($data['password']);
    $role   = 'User';
    $alamat = htmlspecialchars($data['alamat']);
    $gambar = $_FILES["foto"]["name"];
    $sql = "INSERT INTO users (nama, email, no_telepon, username, password, role, alamat, gambar) VALUES ('$nama', '$email', '$no_telepon', '$username', '$password', '$role', '$alamat' , '$gambar')";
    mysqli_query($conn, $sql);

    return mysqli_affected_rows($conn);
}
function tambahmobil($data)
{
    global $conn;
    $target_dir = "../assets/mobil/";
    $target_file = $target_dir . basename($_FILES["foto"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Buat folder uploads jika belum ada
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0755, true);
    }

    // Pindahkan file ke direktori target
    if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
        echo "File " . htmlspecialchars(basename($_FILES["foto"]["name"])) . " telah diunggah.";
    } else {
        echo "Maaf, terjadi kesalahan saat mengunggah file Anda.";
    }
    $merk = htmlspecialchars($data['merk']);
    $model = htmlspecialchars($data['model']);
    $tahun = htmlspecialchars($data['tahun']);
    $warna = htmlspecialchars($data['warna']);
    $harga_perhari = htmlspecialchars($data['harga_perhari']);
    $status   = 'Tersedia';
    $gambar = $_FILES["foto"]["name"];
    $sql = "CALL tambah_mobil_baru('$merk', '$model', '$tahun', '$warna', '$harga_perhari', '$status', '$gambar')";
    mysqli_query($conn, $sql);

    return mysqli_affected_rows($conn);
}
function konfirmasi($id)
{
    global $conn;
    $query = "UPDATE transaksi SET status_transaksi='Belum Bayar' WHERE id_transaksi='$id'";
    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}
function konfirmasiperawatan($id)
{
    global $conn;
    $query = "UPDATE perawatan SET status='Selesai' WHERE id_perawatan='$id'";
    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}
function tambahperawatan($data)
{
    global $conn;

    $id_users = $data['id_users'];
    $id_mobil = $data['id_mobil'];
    $tanggal   = $data['tanggal'];
    $biaya = $data['biaya'];
    $deskripsi = $data['deskripsi'];
    $status = 'Belum Selesai';
    mysqli_query($conn, "CALL TambahPerawatanMobil('$id_mobil', '$id_users', '$tanggal', '$deskripsi', '$biaya', '$status')");

    return mysqli_affected_rows($conn);
}
function hapus($id)
{
    global $conn;
    $query = "DELETE FROM users WHERE id_users='$id'";
    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}
function hapuscustomer($id)
{
    global $conn;
    $query = "DELETE FROM users WHERE id_users='$id'";
    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}
function ubahmobil($data)
{
    global $conn;
    $id_mobil = htmlspecialchars($data['id_mobil']);
    $merk = htmlspecialchars($data['merk']);
    $model = htmlspecialchars($data['model']);
    $tahun = htmlspecialchars($data['tahun']);
    $warna = htmlspecialchars($data['warna']);
    $harga_perhari = htmlspecialchars($data['harga_perhari']);
    $status   = htmlspecialchars($data['status']);
    $gambar = $_FILES["gambar"]["name"];

    if ($gambar) {
        $target_dir = "../assets/mobil/";
        $target_file = $target_dir . basename($_FILES['gambar']['name']);
        move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file);

        // Hapus gambar lama jika ada
        $query = mysqli_query($conn, "SELECT gambar FROM mobil WHERE id_mobil='$id_mobil'");
        $user = mysqli_fetch_assoc($query);
        if ($user['gambar']) {
            unlink($target_dir . $user['gambar']);
        }
        $sql = "UPDATE mobil SET merk='$merk', model='$model', tahun='$tahun', warna='$warna', harga_perhari='$harga_perhari', status='$status', gambar='$gambar' WHERE id_mobil='$id_mobil'";
        mysqli_query($conn, $sql);
        echo "<script>alert('Data Mobil Berhasil diubah');document.location.href='mobil.php';</script>";
    } else {
        $sql = "UPDATE mobil SET merk='$merk', model='$model', tahun='$tahun', warna='$warna', harga_perhari='$harga_perhari', status='$status', gambar='$gambar' WHERE id_mobil='$id_mobil'";
        mysqli_query($conn, $sql);
        echo "<script>alert('Data Mobil Berhasil diubah');document.location.href='mobil.php';</script>";
    }



    return mysqli_affected_rows($conn);
}
function ubah($data)
{
    global $conn;
    $id = htmlspecialchars($data['id_users']);
    $nama = htmlspecialchars($data['nama']);
    $email = htmlspecialchars($data['email']);
    $no_telepon = htmlspecialchars($data['no_telepon']);
    $username = htmlspecialchars($data['username']);
    $role   = htmlspecialchars($data['role']);
    $alamat = htmlspecialchars($data['alamat']);
    $gambar = $_FILES['gambar']['name'];

    if ($gambar) {
        $target_dir = "../assets/foto/";
        $target_file = $target_dir . basename($_FILES['gambar']['name']);
        move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file);

        // Hapus gambar lama jika ada
        $query = mysqli_query($conn, "SELECT gambar FROM users WHERE id_users='$id'");
        $user = mysqli_fetch_assoc($query);
        if ($user['gambar']) {
            unlink($target_dir . $user['gambar']);
        }
        $sql = "UPDATE users SET nama='$nama', email='$email', no_telepon='$no_telepon', username='$username', role='$role', alamat='$alamat', gambar='$gambar' WHERE id_users='$id'";
        mysqli_query($conn, $sql);
        echo "<script>alert('Data admin Berhasil diubah');document.location.href='admin.php';</script>";
    } else {
        $sql = "UPDATE users SET nama='$nama', email='$email', no_telepon='$no_telepon', username='$username', role='$role', alamat='$alamat' WHERE id_users='$id'";
        mysqli_query($conn, $sql);
        echo "<script>alert('Data admin Berhasil diubah');document.location.href='admin.php';</script>";
    }



    return mysqli_affected_rows($conn);
}
function hapusmobil($id)
{
    global $conn;
    $query = "DELETE FROM mobil WHERE id='$id'";
    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}
