<?php
require 'functions.php';
include 'templateadmin/header.php';
include 'templateadmin/sidebar.php';

$admin = index("SELECT * FROM users WHERE role='Admin'");
?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Data Admin</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">Administrator</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <a href="tambahadmin.php" class="btn btn-primary"><i class="bi bi-plus mb-5"></i> Tambah</a>

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Data Admin</h5>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        <b>N</b>o
                                    </th>
                                    <th>Nama</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Nomor Telepon</th>
                                    <th>Alamat</th>
                                    <th>Role</th>
                                    <th>Gambar</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                foreach ($admin as $adm) :
                                ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><?= $adm['nama'] ?></td>
                                        <td><?= $adm['username'] ?></td>
                                        <td><?= $adm['email'] ?></td>
                                        <td><?= $adm['no_telepon'] ?></td>
                                        <td><?= $adm['alamat'] ?></td>
                                        <td><?= $adm['role'] ?></td>
                                        <td><img src="../assets/foto/<?= $adm['gambar'] ?>" style="width: 100px; height: 100px;" alt="foto"></td>
                                        <td> <a href="hapus.php?id=<?= $adm['id_users'] ?>" class="btn btn-danger"><i class="bi bi-trash"></i></a></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include 'templateadmin/footer.php';
?>