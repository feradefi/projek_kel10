<?php

require 'functions.php';
include 'templateadmin/header.php';
include 'templateadmin/sidebar.php';

$transaksi = index("SELECT * FROM vw_detail_penyewaan");
?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Data Transaksi</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">Transaksi</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Data Trnsaksi</h5>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nama</th>
                                    <th>Merk</th>
                                    <th>Model</th>
                                    <th>Tanggal Mulai</th>
                                    <th>Tanggal Selesai</th>
                                    <th>Total Biaya</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                foreach ($transaksi as $adm) :
                                ?>
                                    <tr>
                                        <td><?= $adm['id_transaksi'] ?></td>
                                        <td><?= $adm['nama'] ?></td>
                                        <td><?= $adm['merk'] ?></td>
                                        <td><?= $adm['model'] ?></td>
                                        <td><?= $adm['tanggal_mulai'] ?></td>
                                        <td><?= $adm['tanggal_selesai'] ?></td>
                                        <td><?= $adm['total_biaya'] ?></td>
                                        <td><?= $adm['status_transaksi'] ?></td>
                                        <td> <?php if($adm['status_transaksi'] == "Pending") : ?><a href="konfirmasi.php?id=<?= $adm['id_transaksi'] ?>" class="btn btn-success mb-1">Setujui</a><?php endif; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include 'templateadmin/footer.php';
?>