<?php

require 'functions.php';
include 'templateadmin/header.php';
include 'templateadmin/sidebar.php';

$perawatan = index("SELECT * FROM riwayat_perawatan");
?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Data Perawatan</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">Perawatan</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Data Perawatan</h5>
                        <a href="tambahperawatan.php" class="btn btn-primary"><i class="bi bi-plus mb-5"></i> Tambah</a>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nama Pengguna</th>
                                    <th>No Telepon</th>
                                    <th>Merk Mobil</th>
                                    <th>Model</th>
                                    <th>Tanggal Perawatan</th>
                                    <th>Deskripsi Perawatan</th>
                                    <th>Biaya Perawatan</th>
                                    <th>Status Perawatan</th>
                                    <th>aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                foreach ($perawatan as $adm) :
                                ?>
                                    <tr>
                                        <td><?= $adm['id_perawatan'] ?></td>
                                        <td><?= $adm['nama_pengguna'] ?></td>
                                        <td><?= $adm['no_telepon'] ?></td>
                                        <td><?= $adm['merk'] ?></td>
                                        <td><?= $adm['model'] ?></td>
                                        <td><?= $adm['tanggal'] ?></td>
                                        <td><?= $adm['deskripsi'] ?></td>
                                        <td><?= $adm['biaya'] ?></td>
                                        <td><?= $adm['status_perawatan'] ?></td>
                                        <td>
                                            <?php if($adm['status_perawatan'] == "Belum Selesai") : ?>
                                                <a href="konfirmasiperawatan.php?id=<?= $adm['id_perawatan'] ?>" class="btn btn-primary">konfirmasi</a>
                                            <?php elseif($adm['status_perawatan'] == "Selesai") : ?>
                                                <button class="btn btn-success">Sukses</button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include 'templateadmin/footer.php';
?>