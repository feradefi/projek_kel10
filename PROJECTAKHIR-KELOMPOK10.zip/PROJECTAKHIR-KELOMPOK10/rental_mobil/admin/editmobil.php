<?php

require 'functions.php';
include 'templateadmin/header.php';
include 'templateadmin/sidebar.php';

$id = $_GET['id'];

$data = index("SELECT * FROM mobil WHERE id_mobil='$id'")[0];

if (isset($_POST['submit'])) {
    ubahmobil($_POST);
}
?>


<main id="main" class="main">

    <div class="pagetitle">
        <h1>Data Admin</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">EditMobil</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Edit Mobil</h5>

                        <!-- No Labels Form -->
                        <form class="row g-3" action="" method="post" enctype="multipart/form-data">
                            <div class="col-md-12">
                                <input type="text" name="merk" class="form-control" value="<?= $data["merk"] ?>">
                                <input type="hidden" name="id_mobil" value="<?= $data["id_mobil"] ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="model" class="form-control" value="<?= $data["model"] ?>">
                            </div>
                            <div class=" col-md-6">
                                <input type="text" class="form-control" name="harga_perhari" value="<?= $data["harga_perhari"] ?>">
                            </div>
                            <div class=" col-12">
                                <input type="text" name="warna" class="form-control" value="<?= $data["warna"] ?>">
                            </div>
                            <div class=" col-md-6">
                                <input type="text" name="tahun" class="form-control" value="<?= $data["tahun"] ?>">
                            </div>
                            <div class=" col-md-6">
                                <label for="">status</label>
                                <select name="status" class="form-select" id="">
                                    <option value="<?= $data['status'] ?>"><?= $data['status'] ?></option>
                                    <option value="Dipinjam">Dipinjam</option>
                                    <option value="Perbaikan">Perbaikan</option>
                                    <option value="Tersedia">Tersedia</option>
                                </select>
                            </div>
                            <div class=" col-md-6">
                                <input type="file" name="gambar" class="form-control" value="<?= $data['gambar'] ?>">
                                <img src="../assets/mobil/<?= $data['gambar'] ?>" style="width: 200px; height: 200px;" alt="foto">
                            </div>
                            <div class="text-center">
                                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                <a href="mobil.php" type="reset" class="btn btn-secondary">Kembali</a>
                            </div>
                        </form><!-- End No Labels Form -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include 'templateadmin/footer.php';
?>