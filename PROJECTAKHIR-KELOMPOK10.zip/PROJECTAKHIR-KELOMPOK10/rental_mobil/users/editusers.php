<?php

require 'functions.php';
include 'templateadmin/header.php';

$id = $_GET['id'];

$data = index("SELECT * FROM users WHERE id_users='$id'")[0];

if (isset($_POST['submit'])) {
    if (ubah($_POST) > 0) {
        echo "<script>alert('Data admin Berhasil diubah');document.location.href='admin.php';</script>";
    } else {
        echo "<script>alert('Data admin Gagal diubah');";
    }
}
?>


<main id="main" class="main">

    <div class="pagetitle">
        <h1>Data Admin</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item active">Administrator</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Edit Admin</h5>

                        <!-- No Labels Form -->
                        <form class="row g-3" action="" method="post" enctype="multipart/form-data">
                            <div class="col-md-12">
                                <label for="">Nama</label>
                                <input type="text" name="nama" class="form-control" value="<?= $data["nama"] ?>">
                                <input type="hidden" name="id_users" value="<?= $data["id_users"] ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="">Username</label>
                                <input type="text" name="username" class="form-control" value="<?= $data["username"] ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="">Email</label>
                                <input type="email" class="form-control" name="email" value="<?= $data['email'] ?>">
                            </div>
                            <div class="col-md-12">
                                <label for="">Nomor Telepon</label>
                                <input type="text" class="form-control" name="no_telepon" value="<?= $data['no_telepon'] ?>">
                            </div>

                            <div class=" col-12">
                                <label for="">Alamat</label>
                                <input type="text" name="alamat" class="form-control" value="<?= $data["alamat"] ?>">
                            </div>
                            <div class=" col-md-6">
                                <label for="">Role</label>
                                <select name="role" class="form-select" id="">
                                    <option value="<?= $data['role'] ?>"><?= $data['role'] ?></option>
                                    <option value="User">User</option>
                                    <option value="Admin">Admin</option>
                                </select>
                            </div>
                            <div class=" col-md-6">
                                <label for="">Gambar</label>
                                <input type="file" name="gambar" class="form-control">
                                <img src="../assets/foto/<?= $data['gambar'] ?>" class="mt-3" style="width: 200px; height: 200px;" alt="foto">
                            </div>
                            <div class="text-center">
                                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                <a href="admin.php" type="reset" class="btn btn-secondary">Kembali</a>
                            </div>
                        </form><!-- End No Labels Form -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include 'templateadmin/footer.php';
?>