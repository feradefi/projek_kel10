<?php
include '../koneksi.php';

function query($query)
{
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}
function ubah($data)
{
    global $conn;
    $id = htmlspecialchars($data['id_users']);
    $nama = htmlspecialchars($data['nama']);
    $email = htmlspecialchars($data['email']);
    $no_telepon = htmlspecialchars($data['no_telepon']);
    $username = htmlspecialchars($data['username']);
    $role   = htmlspecialchars($data['role']);
    $alamat = htmlspecialchars($data['alamat']);
    $gambar = $_FILES['gambar']['name'];

    if ($gambar) {
        $target_dir = "../assets/foto/";
        $target_file = $target_dir . basename($_FILES['gambar']['name']);
        move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file);

        // Hapus gambar lama jika ada
        $query = mysqli_query($conn, "SELECT gambar FROM users WHERE id_users='$id'");
        $user = mysqli_fetch_assoc($query);
        if ($user['gambar']) {
            unlink($target_dir . $user['gambar']);
        }
        $sql = "UPDATE users SET nama='$nama', email='$email', no_telepon='$no_telepon', username='$username', role='$role', alamat='$alamat', gambar='$gambar' WHERE id_users='$id'";
        mysqli_query($conn, $sql);
        echo "<script>alert('Data profil Berhasil tersimpan, Silahkan Login Ulang untuk melihat perubahan');document.location.href='profil.php';</script>";
    } else {
        $sql = "UPDATE users SET nama='$nama', email='$email', no_telepon='$no_telepon', username='$username', role='$role', alamat='$alamat' WHERE id_users='$id'";
        mysqli_query($conn, $sql);
        echo "<script>alert('Data profil Berhasil tersimpan, Silahkan Login Ulang untuk melihat perubahan');document.location.href='profil.php';</script>";
    }
    return mysqli_affected_rows($conn);
}
function kembalikan($id)
{
    global $conn;
    $query = "UPDATE transaksi SET status_transaksi='Selesai' WHERE id_transaksi='$id'";
    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}
function tambahtransaksi($data)
{
    global $conn;

    $id_users = $data['id_users'];
    $id_mobil = $data['id_mobil'];
    $tanggal_mulai = date('Y-m-d');
    $tanggal_Selesai = $data['tanggal_Selesai'];
    mysqli_query($conn, "CALL TambahDataTransaksi('$id_users', '$id_mobil', '$tanggal_mulai', '$tanggal_Selesai', '', 'Pending', @new_id)");
    echo "<script>alert('Data Transaksi Berhasil ditambahkan');document.location.href='daftartransaksi.php';</script>";

    return mysqli_affected_rows($conn);
}
function tambahpembayaran($data)
{
    global $conn;

    $id_transaksi = $data['id_transaksi'];
    $id_mobil = $data['id_mobil'];
    $metode_pembayaran = $data['metode_pembayaran'];
    $tanggal_pembayaran = date('Y-m-d');
    $jumlah_pembayaran = $data['jumlah_pembayaran'];
    mysqli_query($conn, "CALL TambahDataPembayaran('','$id_transaksi', '$id_mobil', '$metode_pembayaran', '$tanggal_pembayaran', '$jumlah_pembayaran', 'LUNAS', '0')");
    echo "<script>alert('Pembayaran Berhasil');document.location.href='daftartransaksi.php';</script>";

    return mysqli_affected_rows($conn);
}

