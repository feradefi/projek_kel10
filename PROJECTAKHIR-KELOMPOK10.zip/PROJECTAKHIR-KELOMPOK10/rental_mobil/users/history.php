<?php
require 'functions.php';
include 'templateusers/header.php';
include 'templateusers/sidebar.php';

$id = $_SESSION['id_users'];
$history = query("SELECT * FROM riwayat_transaksi WHERE id_users = $id");
?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>History Transaksi</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item active">History Transaksi</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">History Transaksi</h5>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nama</th>
                                    <th>Merk</th>
                                    <th>Model</th>
                                    <th>Tanggal Mulai</th>
                                    <th>Tanggal Selesai</th>
                                    <th>Status Transaksi</th>
                                    <th>Metode Pembayaran</th>
                                    <th>Status Pembayaran</th>
                                    <th>Denda</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                foreach ($history as $adm) :
                                ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><?= $adm['Nama Lengkap'] ?></td>
                                        <td><?= $adm['Merk Mobil'] ?></td>
                                        <td><?= $adm['Model Mobil'] ?></td>
                                        <td><?= $adm['Tanggal Mulai'] ?></td>
                                        <td><?= $adm['Tanggal Selesai'] ?></td>
                                        <td><?= $adm['Status Transaksi'] ?></td>
                                        <td><?= $adm['Metode Pembayaran'] ?></td>
                                        <td><?= $adm['Status Pembayaran'] ?></td>
                                        <td><?= $adm['Denda'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include 'templateusers/footer.php';
?>