<?php

require 'functions.php';
include 'templateusers/header.php';
include 'templateusers/sidebar.php';

if (isset($_POST['ubahpassword'])) {
    $id = $_POST['id'];
    $passwordlama = $_POST['passwordlama'];
    $passwordsaatini = $_POST['passwordsaatini'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];

    // var_dump($id, $passwordlama, $passwordsaatini, $password, $password2);

    if ($passwordlama == $passwordsaatini) {
        if ($password == $password2) {
            $query = "UPDATE users SET password='$password' WHERE id_users='$id'";
            mysqli_query($conn, $query);
            echo "<script>alert('Password Berhasil diubah');document.location.href='profil.php';</script>";
        } else {
            echo "<script>alert('Password baru dan konfirmasi tidak sama');</script>";
        }
    } else {
        echo "<script>alert('Password lama yang anda masukkan tidak sesuai');</script>";
    }
}

if (isset($_POST['edit'])) {
    ubah($_POST);
}
?>
<main id="main" class="main">

    <div class="pagetitle">
        <h1>Profile</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item">Users</li>
                <li class="breadcrumb-item active">Profile</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section profile">
        <div class="row">
            <div class="col-xl-4">

                <div class="card">
                    <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">

                        <img src="../assets/foto/<?= $_SESSION['gambar'] ?>" alt="Profile" class="rounded-circle">
                        <h2><?= $_SESSION['nama'] ?></h2>
                        <h3><?= $_SESSION['role'] ?></h3>
                    </div>
                </div>

            </div>

            <div class="col-xl-8">

                <div class="card">
                    <div class="card-body pt-3">
                        <!-- Bordered Tabs -->
                        <ul class="nav nav-tabs nav-tabs-bordered">

                            <li class="nav-item">
                                <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Overview</button>
                            </li>

                            <li class="nav-item">
                                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">Edit Profile</button>
                            </li>

                            <li class="nav-item">
                                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-change-password">Change Password</button>
                            </li>

                        </ul>
                        <div class="tab-content pt-2">

                            <div class="tab-pane fade show active profile-overview" id="profile-overview">
                                <h5 class="card-title">Detail Profil</h5>

                                <div class="row">
                                    <div class="col-lg-3 col-md-4 label ">Nama</div>
                                    <div class="col-lg-9 col-md-8"><?= $_SESSION['nama'] ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-3 col-md-4 label">Alamat</div>
                                    <div class="col-lg-9 col-md-8"><?= $_SESSION['alamat'] ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-3 col-md-4 label">Nomor Telepon</div>
                                    <div class="col-lg-9 col-md-8"><?= $_SESSION['no_telepon'] ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-3 col-md-4 label">Email</div>
                                    <div class="col-lg-9 col-md-8"><?= $_SESSION['email'] ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-3 col-md-4 label">Username</div>
                                    <div class="col-lg-9 col-md-8"><?= $_SESSION['username'] ?></div>
                                </div>

                            </div>

                            <div class="tab-pane fade profile-edit pt-3" id="profile-edit">

                                <!-- Profile Edit Form -->
                                <form action="" method="post" enctype="multipart/form-data">
                                    <div class="row mb-3">
                                        <label for="profileImage" class="col-md-4 col-lg-3 col-form-label">Profile Image</label>
                                        <div class="col-md-8 col-lg-9">
                                            <img src="../assets/foto/<?= $_SESSION['gambar'] ?>" alt="Profile">
                                            <div class="pt-2">
                                                <input type="file" name="gambar" class="form-control" value="<?= $data['gambar'] ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <label for="" class="col-md-4 col-lg-3 col-form-label">Nama</label>
                                        <div class="col-md-8 col-lg-9">
                                            <input type="text" name="nama" class="form-control" value="<?= $_SESSION["nama"] ?>">
                                            <input type="hidden" name="id_users" value="<?= $_SESSION["id_users"] ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="" class="col-md-4 col-lg-3 col-form-label">Username</label>
                                        <div class="col-md-8 col-lg-9">
                                            <input type="text" name="username" class="form-control" value="<?= $_SESSION["username"] ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="" class="col-md-4 col-lg-3 col-form-label">Email</label>
                                        <div class="col-md-8 col-lg-9">
                                            <input type="email" name="email" class="form-control" value="<?= $_SESSION["email"] ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="" class="col-md-4 col-lg-3 col-form-label">Nomor Telepon</label>
                                        <div class="col-md-8 col-lg-9">
                                            <input type="text" name="no_telepon" class="form-control" value="<?= $_SESSION["no_telepon"] ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="" class="col-md-4 col-lg-3 col-form-label">Alamat</label>
                                        <div class="col-md-8 col-lg-9">
                                            <input type="text" name="alamat" class="form-control" value="<?= $_SESSION["alamat"] ?>">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="" class="col-md-4 col-lg-3 col-form-label">Role</label>
                                        <div class="col-md-8 col-lg-9">
                                            <select name="role" class="form-select" id="">
                                                <option value="<?= $_SESSION['role'] ?>"><?= $_SESSION['role'] ?></option>
                                                <option value="User">User</option>
                                                <option value="Admin">Admin</option>
                                            </select>
                                        </div>

                                    </div>

                                    <div class="text-center">
                                        <button type="submit" name="edit" class="btn btn-primary">Save Perubahan</button>
                                    </div>
                                </form><!-- End Profile Edit Form -->

                            </div>



                            <div class="tab-pane fade pt-3" id="profile-change-password">
                                <form method="post" action="">
                                    <input type="hidden" name="id" value="<?= $_SESSION['id_users'] ?>">
                                    <input type="hidden" name="passwordsaatini" value="<?= $_SESSION['password'] ?>">
                                    <div class="row mb-3">
                                        <label for="passwordlama" class="col-md-4 col-lg-3 col-form-label">Password Lama</label>
                                        <div class="col-md-8 col-lg-9">
                                            <input name="passwordlama" type="password" class="form-control" id="passwordlama">
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <label for="password" class="col-md-4 col-lg-3 col-form-label">Password Baru</label>
                                        <div class="col-md-8 col-lg-9">
                                            <input name="password" type="password" class="form-control" id="password">
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <label for="password2" class="col-md-4 col-lg-3 col-form-label">Konfirmasi Password Baru</label>
                                        <div class="col-md-8 col-lg-9">
                                            <input name="password2" type="password" class="form-control" id="password2">
                                        </div>
                                    </div>

                                    <div class="text-center">
                                        <button type="submit" name="ubahpassword" class="btn btn-primary">Ubah Password</button>
                                    </div>
                                </form><!-- End Change Password Form -->

                            </div>

                        </div><!-- End Bordered Tabs -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main><!-- End #main -->
<?php

include 'templateusers/footer.php';
?>