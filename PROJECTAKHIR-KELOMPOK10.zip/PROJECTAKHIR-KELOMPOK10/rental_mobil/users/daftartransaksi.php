<?php

require 'functions.php';
include 'templateusers/header.php';
include 'templateusers/sidebar.php';

$id = $_SESSION['id_users'];
$transaksi = query("SELECT * FROM vw_detail_penyewaan WHERE id_users = $id");
?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Data Transaksi</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item">Data Transaksi</li>
                <li class="breadcrumb-item active">Transaksi</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Data Trnsaksi</h5>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nama</th>
                                    <th>Alamat</th>
                                    <th>Nomor Telepon</th>
                                    <th>Merk</th>
                                    <th>Model</th>
                                    <th>Tahun</th>
                                    <th>Tanggal Mulai</th>
                                    <th>Tanggal Selesai</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                foreach ($transaksi as $adm) :
                                ?>
                                    <tr>
                                        <td><?= $adm['id_transaksi'] ?></td>
                                        <td><?= $adm['nama'] ?></td>
                                        <td><?= $adm['alamat'] ?></td>
                                        <td><?= $adm['no_telepon'] ?></td>
                                        <td><?= $adm['merk'] ?></td>
                                        <td><?= $adm['model'] ?></td>
                                        <td><?= $adm['tahun'] ?></td>
                                        <td><?= $adm['tanggal_mulai'] ?></td>
                                        <td><?= $adm['tanggal_selesai'] ?></td>
                                        <td>
                                        <?php if($adm['status_transaksi'] == "Belum Bayar") : ?>
                                            <a href="pembayaran.php?id=<?= $adm['id_transaksi'] ?>" class="btn btn-primary mb-1">Bayar</a>
                                        <?php elseif($adm['status_transaksi'] == "Belum Selesai") : ?>
                                            <a href="kembalikan.php?id_transaksi=<?= $adm['id_transaksi'] ?>" class="btn btn-warning mb-1">Kembalikan</a>
                                        <?php else : ?>
                                            <button class="btn btn-secondary">Tidak Ada Aksi</button>
                                        <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include 'templateusers/footer.php';
?>