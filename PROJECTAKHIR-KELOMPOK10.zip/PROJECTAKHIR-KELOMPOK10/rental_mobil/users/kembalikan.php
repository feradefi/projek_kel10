<?php
require 'functions.php';
$id = $_GET['id_transaksi'];

if (kembalikan($id) > 0) {
    echo "<script>alert('Data Berhasil Dikembalikan');document.location.href='daftartransaksi.php';</script>";
} else {
    echo "<script>alert('Terjadi kesalahan saat Mengembalikan');</script>";
}
