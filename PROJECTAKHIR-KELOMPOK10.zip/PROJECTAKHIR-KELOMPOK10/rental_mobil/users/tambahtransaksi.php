<?php

require 'functions.php';
include 'templateusers/header.php';
// include 'templateusers/sidebar.php';
$id = $_GET['id'];

if (isset($_POST['submit'])) {
    if (tambahtransaksi($_POST) > 0) {
        echo "<script>alert('Data transaksi Berhasil ditambahkan');document.location.href='dashboard.php';</script>";
    } else {
        echo "<script>alert('Data transaksi Gagal ditambahkan');";
    }
}

$mobil = query("SELECT * FROM mobil WHERE id_mobil='$id'")[0];
?>


<main id="main" class="main">

    <div class="pagetitle">
        <h1>Proses Transaksi</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item">Mobil</li>
                <li class="breadcrumb-item active">Transaksi</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-sm-4">
                <div class="card">
                    <img src="../assets/mobil/<?= $mobil['gambar'] ?>" class="card-img-top" style="height:200px;">
                    <div class="card-body" style="background:#ddd">
                        <h5 class="card-title"><?= $mobil['merk'] ?></h5>
                        <h6 class="card-subtitle"><?= $mobil['model'] ?></h6>
                    </div>
                    <ul class="list-group list-group-flush">

                        <?php if ($mobil['status'] == 'Tersedia') { ?>
                            <li class="list-group-item bg-primary text-white">
                                <i class="fa fa-check"></i> Tersedia
                            </li>
                        <?php } else { ?>
                            <li class="list-group-item bg-danger text-white">
                                <i class="fa fa-close"></i> Tidak Tersedia
                            </li>
                        <?php } ?>
                        <li class="list-group-item bg-dark text-white">
                            <i class="fa fa-money"></i> Rp. <?= number_format($mobil['harga_perhari'], 2, ',', '.') ?>/ day
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="card">
                    <div class="card-body">
                        <form method="post" action="">
                            <div class="form-group mt-3">
                                <label for="nama">Nama</label>
                                <input type="text" name="nama" id="nama" class="form-control" readonly value="<?= $_SESSION['nama'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="alamat">Alamat</label>
                                <input type="text" name="alamat" id="alamat" class="form-control" readonly value="<?= $_SESSION['alamat'] ?>">
                            </div>
                            <div class=" form-group">
                                <label for="no_telepon">Telepon</label>
                                <input type="text" name="no_telepon" id="no_telepon" class="form-control" readonly value="<?= $_SESSION['no_telepon'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="tanggal_Selesai">Tanggal Selesai</label>
                                <input type="date" name="tanggal_Selesai" id="tanggal_Selesai" required class="form-control">
                            </div>
                            
                            <input type="hidden" value="<?php echo $_SESSION['id_users']; ?>" name="id_users">
                            <input type="hidden" value="<?php echo $mobil['id_mobil']; ?>" name="id_mobil">
                            <input type="hidden" value="<?php echo $mobil['harga_perhari']; ?>" name="harga">
                            <hr />
                            <?php if ($mobil['status'] == 'Tersedia') { ?>
                                <button type="submit" name="submit" class="btn btn-primary float-right">Booking Now</button>
                            <?php } else { ?>
                                <button type="submit" class="btn btn-danger float-right" disabled>Booking Now</button>
                            <?php } ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

</main>
<?php

include 'templateusers/footer.php';
?>