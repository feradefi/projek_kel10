<?php

require 'functions.php';
include 'templateusers/header.php';
include 'templateusers/sidebar.php';
$id = $_GET['id'];
$mbl = query("SELECT * FROM mobil WHERE id_mobil='$id'")[0];
?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Data Mobil</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item active">mobil</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Data Mobil</h5>
                        <img src="../assets/mobil/<?= $mbl['gambar'] ?>" alt="Gambar Mobil">
                        <table class="table table-striped">
                            <tr>
                                <th>Merk</th>
                                <td><?= $mbl['merk'] ?></td>
                            </tr>
                            <tr>
                                <th>Model</th>
                                <td><?= $mbl['model'] ?></td>
                            </tr>
                            <tr>
                                <th>Tahun</th>
                                <td><?= $mbl['tahun'] ?></td>
                            </tr>
                            <tr>
                                <th>warna</th>
                                <td><?= $mbl['warna'] ?></td>
                            </tr>
                            <tr>
                                <th>harga perhari</th>
                                <td><?= $mbl['harga_perhari'] ?></td>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td><?= $mbl['status'] ?></td>
                            </tr>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main>
<?php

include 'templateusers/footer.php';
?>