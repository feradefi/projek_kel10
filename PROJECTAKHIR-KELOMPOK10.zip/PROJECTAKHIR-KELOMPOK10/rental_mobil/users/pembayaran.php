<?php

require 'functions.php';
include 'templateusers/header.php';
// include 'templateusers/sidebar.php';
$id = $_GET['id'];

if (isset($_POST['submit'])) {
    if (tambahpembayaran($_POST) > 0) {
        echo "<script>alert('Data Pembayaran Berhasil');document.location.href='daftartransaksi.php';</script>";
    } else {
        echo "<script>alert('Data Pembayaran Gagal');";
    }
}

$transaksi = query("SELECT * FROM transaksi WHERE id_transaksi='$id'")[0];
?>


<main id="main" class="main">

    <div class="pagetitle">
        <h1>Proses Transaksi</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item">Mobil</li>
                <li class="breadcrumb-item active">Transaksi</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <form method="post" action="">
                            <div class="form-group mt-3">
                                <label for="total_biaya">Jumlah Pembayaran</label>
                                <input type="text" name="jumlah_pembayaran" id="total_biaya" class="form-control" readonly value="<?= $transaksi['total_biaya'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="metode">Metode Pembayaran</label>
                                <select name="metode_pembayaran" id="metode" class="form-control">
                                    <option value="BRI">BRI</option>
                                    <option value="BNI">BNI</option>
                                    <option value="BTN">BTN</option>
                                    <option value="MANDIRI">MANDIRI</option>
                                    <option value="DANA">DANA</option>
                                </select>
                            </div>
                            <input type="hidden" value="<?php echo $transaksi['id_transaksi']; ?>" name="id_transaksi">
                            <input type="hidden" value="<?php echo $transaksi['id_mobil']; ?>" name="id_mobil">
                            <hr />
                            <button type="submit" name="submit" class="btn btn-primary float-right">Bayar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

</main>
<?php

include 'templateusers/footer.php';
?>