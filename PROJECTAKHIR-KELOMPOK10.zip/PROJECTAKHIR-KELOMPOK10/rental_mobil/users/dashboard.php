<?php
require 'functions.php';
include '../koneksi.php';
include 'templateusers/header.php';
include 'templateusers/sidebar.php';

$mobil = query("SELECT * FROM mobil");
?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Dashboard</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="row">

            <!-- Sales Card -->
            <?php foreach ($mobil as $mbl) : ?>
                <div class="col-sm-4">
                    <div class="card">
                        <img src="../assets/mobil/<?= $mbl['gambar'] ?>" class="card-img-top" style="height:200px;">
                        <div class="card-body" style="background:#ddd">
                            <h5 class="card-title"><?= $mbl['merk'] ?></h5>
                            <h5 class="card-subtitle"><?= $mbl['model'] ?></h5>

                        </div>
                        <ul class="list-group list-group-flush">

                            <?php if ($mbl['status'] == 'Tersedia') : ?>
                                <li class="list-group-item bg-primary text-white">
                                <?php elseif ($mbl['status'] == 'Dipinjam') : ?>
                                <li class="list-group-item bg-danger text-white">
                                <?php endif; ?>
                                <i class="fa fa-close"></i> <?= $mbl['status'] ?>
                                </li>

                                <li class="list-group-item bg-dark text-white">
                                    <i class="fa fa-money"></i> Rp. <?= number_format($mbl['harga_perhari'], 2, ',', '.')  ?> / hari
                                </li>
                        </ul>
                        <div class="card-body mt-3">
                            <center><a href="tambahtransaksi.php?id=<?= $mbl['id_mobil'] ?>" class="btn btn-success">Booking</a>
                                <a href="detailmobil.php?id=<?= $mbl['id_mobil'] ?>" class="btn btn-info">Detail</a>
                            </center>
                        </div>
                    </div>
                </div><!-- End Sales Card -->
            <?php endforeach; ?>

        </div>
    </section>

</main><!-- End #main -->

<?php

include 'templateusers/footer.php';
?>