-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 13 Jun 2024 pada 09.03
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rental_mobil`
--

DELIMITER $$
--
-- Prosedur
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `TambahDataOmset` (IN `jenis_transaksi` ENUM('Pemasukan','Pengeluaran'), IN `jumlah_transaksi` INT)   BEGIN
    DECLARE total_uang_sebelumnya INT;

    -- Menyimpan total_uang saat ini
    SELECT IFNULL(total_uang, 0) INTO total_uang_sebelumnya FROM omset ORDER BY id_omset DESC LIMIT 1;

    -- Memasukkan data baru ke dalam tabel omset
    INSERT INTO omset (total_uang, jenis_transaksi, jumlah_transaksi) VALUES (
        CASE 
            WHEN jenis_transaksi = 'Pemasukan' THEN total_uang_sebelumnya + jumlah_transaksi
            ELSE total_uang_sebelumnya - jumlah_transaksi
        END,
        jenis_transaksi,
        jumlah_transaksi
    );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `TambahDataTransaksi` (IN `id_user` INT, IN `id_mobil` INT, IN `tanggal_mulai` DATE, IN `tanggal_selesai` DATE, IN `total_biaya` INT, IN `status_transaksi` ENUM('Belum Selesai','Selesai'), OUT `new_id_transaksi` INT)   BEGIN
    INSERT INTO transaksi (id_users, id_mobil, tanggal_mulai, tanggal_selesai, total_biaya, status_transaksi)
    VALUES (id_user, id_mobil, tanggal_mulai, tanggal_selesai, total_biaya, status_transaksi);
    
    SET new_id_transaksi = LAST_INSERT_ID();
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `TambahPerawatanMobil` (IN `p_id_mobil` INT, IN `p_id_users` INT, IN `p_tanggal` DATE, IN `p_deskripsi` TEXT, IN `p_biaya` INT, IN `p_status` ENUM('Belum Selesai','Selesai'))   BEGIN
    INSERT INTO perawatan (id_mobil, id_users, tanggal, deskripsi, biaya, status)
    VALUES (p_id_mobil, p_id_users, p_tanggal, p_deskripsi, p_biaya, p_status);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tambah_mobil_baru` (IN `p_merk` VARCHAR(50), IN `p_model` VARCHAR(50), IN `p_tahun` INT, IN `p_warna` VARCHAR(20), IN `p_harga_perhari` INT, IN `p_status` ENUM('Dipinjam','Tersedia','Perbaikan'), IN `p_gambar` VARCHAR(225))   BEGIN
    INSERT INTO mobil (merk, model, tahun, warna, harga_perhari, status, gambar)
    VALUES (p_merk, p_model, p_tahun, p_warna, p_harga_perhari, p_status, p_gambar);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `TotalMobilDisewaSebulanTerakhir` (IN `merk` VARCHAR(50), OUT `total_penyewaan` INT)   BEGIN
    IF merk IS NOT NULL THEN
        SELECT 
            m.merk, COUNT(t.id_transaksi) INTO @merk, total_penyewaan
        FROM 
            transaksi t
        JOIN 
            mobil m ON t.id_mobil = m.id_mobil
        WHERE 
            t.tanggal_mulai BETWEEN DATE_SUB(CURDATE(), INTERVAL 1 MONTH) AND CURDATE()
            AND m.merk = merk
            AND m.status = 'Dipinjam';
    ELSE
        SELECT 
            m.merk, COUNT(t.id_transaksi) INTO @merk, total_penyewaan
        FROM 
            transaksi t
        JOIN 
            mobil m ON t.id_mobil = m.id_mobil
        WHERE 
            t.tanggal_mulai BETWEEN DATE_SUB(CURDATE(), INTERVAL 1 MONTH) AND CURDATE()
            AND m.status = 'Dipinjam'; -- Hanya memperhatikan mobil yang sedang disewa
    END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `log_hapus_mobil`
--

CREATE TABLE `log_hapus_mobil` (
  `id_mobil` int(11) NOT NULL,
  `merk` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `tahun` int(11) NOT NULL,
  `warna` varchar(20) NOT NULL,
  `harga_perhari` int(11) NOT NULL,
  `status` enum('Dipinjam','Tersedia','Perbaikan') DEFAULT NULL,
  `gambar` varchar(225) NOT NULL,
  `waktu_dihapus` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `mobil`
--

CREATE TABLE `mobil` (
  `id_mobil` int(11) NOT NULL,
  `merk` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `tahun` int(11) NOT NULL,
  `warna` varchar(20) NOT NULL,
  `harga_perhari` int(11) NOT NULL,
  `status` enum('Dipinjam','Tersedia','Perbaikan') DEFAULT NULL,
  `gambar` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `mobil`
--

INSERT INTO `mobil` (`id_mobil`, `merk`, `model`, `tahun`, `warna`, `harga_perhari`, `status`, `gambar`) VALUES
(1, 'Toyota', 'Avanza', 2020, 'Silver', 200000, 'Tersedia', 'avanza.jpg'),
(2, 'Honda', 'City', 2019, 'Red', 250000, 'Dipinjam', 'city.jpg');

--
-- Trigger `mobil`
--
DELIMITER $$
CREATE TRIGGER `after_delete_mobil` AFTER DELETE ON `mobil` FOR EACH ROW BEGIN
    INSERT INTO log_hapus_mobil (id_mobil, merk, model, tahun, warna, harga_perhari, status, gambar, waktu_dihapus)
    VALUES (OLD.id_mobil, OLD.merk, OLD.model, OLD.tahun, OLD.warna, OLD.harga_perhari, OLD.status, OLD.gambar, NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `mobil_dipinjam_view`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `mobil_dipinjam_view` (
`id_mobil` int(11)
,`merk` varchar(50)
,`model` varchar(50)
,`tahun` int(11)
,`warna` varchar(20)
,`tanggal_mulai` date
,`tanggal_Selesai` date
,`nama_pelanggan` varchar(30)
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `mobil_sering_disewa_perbulan`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `mobil_sering_disewa_perbulan` (
`id_mobil` int(11)
,`merk` varchar(50)
,`model` varchar(50)
,`tahun` int(11)
,`warna` varchar(20)
,`jumlah_penyewaan` bigint(21)
,`bulan` varchar(7)
);

-- --------------------------------------------------------

--
-- Struktur dari tabel `omset`
--

CREATE TABLE `omset` (
  `id_omset` int(11) NOT NULL,
  `total_uang` int(11) NOT NULL,
  `jenis_transaksi` enum('Pemasukan','Pengeluaran') NOT NULL,
  `jumlah_transaksi` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `omset`
--

INSERT INTO `omset` (`id_omset`, `total_uang`, `jenis_transaksi`, `jumlah_transaksi`) VALUES
(1, 1000000, 'Pemasukan', 1),
(2, 500000, 'Pengeluaran', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `id_transaksi` int(11) NOT NULL,
  `metode_pembayaran` enum('BRI','BNI','BTN','MANDIRI','DANA','CASH') NOT NULL,
  `tanggal_pembayaran` date NOT NULL,
  `jumlah_pembayaran` int(11) DEFAULT NULL,
  `status` enum('LUNAS','BELUM LUNAS') NOT NULL,
  `denda` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_transaksi`, `metode_pembayaran`, `tanggal_pembayaran`, `jumlah_pembayaran`, `status`, `denda`) VALUES
(1, 1, 'BRI', '2024-06-12', 400000, 'LUNAS', 0),
(2, 2, 'MANDIRI', '2024-06-09', 500000, 'BELUM LUNAS', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `perawatan`
--

CREATE TABLE `perawatan` (
  `id_perawatan` int(11) NOT NULL,
  `id_mobil` int(11) NOT NULL,
  `id_users` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `deskripsi` text NOT NULL,
  `biaya` int(11) NOT NULL,
  `status` enum('Belum Selesai','Selesai') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `perawatan`
--

INSERT INTO `perawatan` (`id_perawatan`, `id_mobil`, `id_users`, `tanggal`, `deskripsi`, `biaya`, `status`) VALUES
(1, 1, 1, '2024-06-10', 'Ganti oli dan filter', 300000, 'Selesai'),
(2, 2, 2, '2024-06-08', 'Perbaikan mesin rusak', 500000, 'Belum Selesai'),
(3, 1, 1, '2024-06-13', 'asjdbnjhbfhdsf', 30000, 'Belum Selesai'),
(4, 2, 1, '2024-06-11', 'ini meja', 1000000, 'Belum Selesai'),
(5, 1, 1, '2024-06-17', 'gabut aja', 50000, 'Belum Selesai');

--
-- Trigger `perawatan`
--
DELIMITER $$
CREATE TRIGGER `after_update_status_perawatan` AFTER UPDATE ON `perawatan` FOR EACH ROW BEGIN
	IF NEW.status = 'Selesai' THEN
	UPDATE mobil
	SET status = 'Tersedia'
	WHERE id_mobil = NEW.id_mobil;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `riwayat_perawatan`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `riwayat_perawatan` (
`id_perawatan` int(11)
,`id_mobil` int(11)
,`nama_pengguna` varchar(50)
,`no_telepon` varchar(15)
,`merk` varchar(50)
,`model` varchar(50)
,`tanggal` date
,`deskripsi` text
,`biaya` int(11)
,`status_perawatan` enum('Belum Selesai','Selesai')
);

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `riwayat_transaksi`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `riwayat_transaksi` (
`ID Transaksi` int(11)
,`Username` varchar(30)
,`No Telepon` varchar(15)
,`Email` varchar(50)
,`Nama Lengkap` varchar(50)
,`Merk Mobil` varchar(50)
,`Model Mobil` varchar(50)
,`Tahun Mobil` int(11)
,`Warna Mobil` varchar(20)
,`Tanggal Mulai` date
,`Tanggal Selesai` date
,`Total Biaya` int(11)
,`Status Transaksi` enum('Belum Selesai','Selesai')
,`Metode Pembayaran` enum('BRI','BNI','BTN','MANDIRI','DANA','CASH')
,`Tanggal Pembayaran` date
,`Jumlah Pembayaran` int(11)
,`Status Pembayaran` enum('LUNAS','BELUM LUNAS')
,`Denda` int(11)
);

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `id_users` int(11) NOT NULL,
  `id_mobil` int(11) NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_Selesai` date NOT NULL,
  `total_biaya` int(11) NOT NULL,
  `status_transaksi` enum('Belum Selesai','Selesai') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_users`, `id_mobil`, `tanggal_mulai`, `tanggal_Selesai`, `total_biaya`, `status_transaksi`) VALUES
(1, 1, 1, '2024-06-10', '2024-06-12', 400000, 'Selesai'),
(2, 2, 2, '2024-06-08', '2024-06-10', 500000, 'Belum Selesai'),
(3, 2, 1, '2024-06-11', '2024-06-14', 0, 'Belum Selesai'),
(4, 2, 1, '2024-06-11', '2024-06-15', 800000, 'Belum Selesai'),
(5, 1, 1, '2024-06-11', '2024-06-14', 600000, 'Belum Selesai'),
(6, 1, 1, '2024-06-11', '2024-06-14', 600000, 'Belum Selesai');

--
-- Trigger `transaksi`
--
DELIMITER $$
CREATE TRIGGER `BeforeInsertTransaksi` BEFORE INSERT ON `transaksi` FOR EACH ROW BEGIN
    DECLARE total_hari INT;

    -- Menghitung jumlah hari sewa
    SET total_hari = DATEDIFF(NEW.tanggal_Selesai, NEW.tanggal_mulai);

    -- Menghitung total biaya sewa
    SET NEW.total_biaya = total_hari * (SELECT harga_perhari FROM mobil WHERE id_mobil = NEW.id_mobil);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_mobil` BEFORE INSERT ON `transaksi` FOR EACH ROW BEGIN
    UPDATE mobil
    SET status = 'Dipinjam'
    WHERE id_mobil = NEW.id_mobil;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id_users` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `no_telepon` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(225) NOT NULL,
  `role` enum('Admin','User') NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `gambar` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id_users`, `username`, `nama`, `no_telepon`, `email`, `password`, `role`, `alamat`, `gambar`) VALUES
(1, 'andini', 'Andini Dwi Cahyani', '083852874077', 'andini@gmail.com', 'admin123', 'Admin', 'Mojokerto', 'andini.jpg'),
(2, 'fera', 'Fera Defi Susanti', '085257219384', 'fera@gmail.com', 'user123', 'User', 'Lumanjang', 'user1.jpg'),
(3, 'mamat', 'M. Badrut Tamam', '081332968997', 'mochtamam2107@gmail.com', '123456', 'Admin', 'Probolinggo', 'IMG_6359-T01qDfEd5-transformed.png'),
(7, 'ngarang', 'Ngarang Yoan', '085625665612', 'moch@gmail.com', '123456', 'User', 'Ngarang', '20220212_141037-removebg-preview (1).png');

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `vw_detail_penyewaan`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `vw_detail_penyewaan` (
`id_transaksi` int(11)
,`id_users` int(11)
,`nama` varchar(50)
,`alamat` varchar(100)
,`no_telepon` varchar(15)
,`id_mobil` int(11)
,`merk` varchar(50)
,`model` varchar(50)
,`tahun` int(11)
,`tanggal_mulai` date
,`tanggal_selesai` date
,`total_biaya` int(11)
,`status_transaksi` enum('Belum Selesai','Selesai')
);

-- --------------------------------------------------------

--
-- Struktur untuk view `mobil_dipinjam_view`
--
DROP TABLE IF EXISTS `mobil_dipinjam_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `mobil_dipinjam_view`  AS SELECT `m`.`id_mobil` AS `id_mobil`, `m`.`merk` AS `merk`, `m`.`model` AS `model`, `m`.`tahun` AS `tahun`, `m`.`warna` AS `warna`, `t`.`tanggal_mulai` AS `tanggal_mulai`, `t`.`tanggal_Selesai` AS `tanggal_Selesai`, `u`.`username` AS `nama_pelanggan` FROM ((`mobil` `m` join `transaksi` `t` on(`m`.`id_mobil` = `t`.`id_mobil`)) join `users` `u` on(`t`.`id_users` = `u`.`id_users`)) WHERE `t`.`status_transaksi` = 'Belum Selesai' ;

-- --------------------------------------------------------

--
-- Struktur untuk view `mobil_sering_disewa_perbulan`
--
DROP TABLE IF EXISTS `mobil_sering_disewa_perbulan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `mobil_sering_disewa_perbulan`  AS SELECT `m`.`id_mobil` AS `id_mobil`, `m`.`merk` AS `merk`, `m`.`model` AS `model`, `m`.`tahun` AS `tahun`, `m`.`warna` AS `warna`, count(`t`.`id_transaksi`) AS `jumlah_penyewaan`, date_format(`t`.`tanggal_mulai`,'%Y-%m') AS `bulan` FROM (`transaksi` `t` join `mobil` `m` on(`t`.`id_mobil` = `m`.`id_mobil`)) GROUP BY `m`.`id_mobil`, date_format(`t`.`tanggal_mulai`,'%Y-%m') ORDER BY date_format(`t`.`tanggal_mulai`,'%Y-%m') DESC, count(`t`.`id_transaksi`) DESC ;

-- --------------------------------------------------------

--
-- Struktur untuk view `riwayat_perawatan`
--
DROP TABLE IF EXISTS `riwayat_perawatan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `riwayat_perawatan`  AS SELECT `p`.`id_perawatan` AS `id_perawatan`, `p`.`id_mobil` AS `id_mobil`, `u`.`nama` AS `nama_pengguna`, `u`.`no_telepon` AS `no_telepon`, `m`.`merk` AS `merk`, `m`.`model` AS `model`, `p`.`tanggal` AS `tanggal`, `p`.`deskripsi` AS `deskripsi`, `p`.`biaya` AS `biaya`, `p`.`status` AS `status_perawatan` FROM ((`perawatan` `p` join `users` `u` on(`p`.`id_users` = `u`.`id_users`)) join `mobil` `m` on(`p`.`id_mobil` = `m`.`id_mobil`)) ;

-- --------------------------------------------------------

--
-- Struktur untuk view `riwayat_transaksi`
--
DROP TABLE IF EXISTS `riwayat_transaksi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `riwayat_transaksi`  AS SELECT `t`.`id_transaksi` AS `ID Transaksi`, `u`.`username` AS `Username`, `u`.`no_telepon` AS `No Telepon`, `u`.`email` AS `Email`, `u`.`nama` AS `Nama Lengkap`, `m`.`merk` AS `Merk Mobil`, `m`.`model` AS `Model Mobil`, `m`.`tahun` AS `Tahun Mobil`, `m`.`warna` AS `Warna Mobil`, `t`.`tanggal_mulai` AS `Tanggal Mulai`, `t`.`tanggal_Selesai` AS `Tanggal Selesai`, `t`.`total_biaya` AS `Total Biaya`, `t`.`status_transaksi` AS `Status Transaksi`, `p`.`metode_pembayaran` AS `Metode Pembayaran`, `p`.`tanggal_pembayaran` AS `Tanggal Pembayaran`, `p`.`jumlah_pembayaran` AS `Jumlah Pembayaran`, `p`.`status` AS `Status Pembayaran`, `p`.`denda` AS `Denda` FROM (((`transaksi` `t` join `users` `u` on(`t`.`id_users` = `u`.`id_users`)) join `mobil` `m` on(`t`.`id_mobil` = `m`.`id_mobil`)) left join `pembayaran` `p` on(`t`.`id_transaksi` = `p`.`id_transaksi`)) ;

-- --------------------------------------------------------

--
-- Struktur untuk view `vw_detail_penyewaan`
--
DROP TABLE IF EXISTS `vw_detail_penyewaan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_detail_penyewaan`  AS SELECT `s`.`id_transaksi` AS `id_transaksi`, `u`.`id_users` AS `id_users`, `u`.`nama` AS `nama`, `u`.`alamat` AS `alamat`, `u`.`no_telepon` AS `no_telepon`, `m`.`id_mobil` AS `id_mobil`, `m`.`merk` AS `merk`, `m`.`model` AS `model`, `m`.`tahun` AS `tahun`, `s`.`tanggal_mulai` AS `tanggal_mulai`, `s`.`tanggal_Selesai` AS `tanggal_selesai`, `s`.`total_biaya` AS `total_biaya`, `s`.`status_transaksi` AS `status_transaksi` FROM ((`transaksi` `s` join `users` `u` on(`s`.`id_users` = `u`.`id_users`)) join `mobil` `m` on(`s`.`id_mobil` = `m`.`id_mobil`)) ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `log_hapus_mobil`
--
ALTER TABLE `log_hapus_mobil`
  ADD PRIMARY KEY (`id_mobil`);

--
-- Indeks untuk tabel `mobil`
--
ALTER TABLE `mobil`
  ADD PRIMARY KEY (`id_mobil`);

--
-- Indeks untuk tabel `omset`
--
ALTER TABLE `omset`
  ADD PRIMARY KEY (`id_omset`);

--
-- Indeks untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`),
  ADD KEY `id_transaksi` (`id_transaksi`);

--
-- Indeks untuk tabel `perawatan`
--
ALTER TABLE `perawatan`
  ADD PRIMARY KEY (`id_perawatan`),
  ADD KEY `id_mobil` (`id_mobil`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_users` (`id_users`),
  ADD KEY `id_mobil` (`id_mobil`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_users`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `mobil`
--
ALTER TABLE `mobil`
  MODIFY `id_mobil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `omset`
--
ALTER TABLE `omset`
  MODIFY `id_omset` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `perawatan`
--
ALTER TABLE `perawatan`
  MODIFY `id_perawatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id_users` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `pembayaran_ibfk_1` FOREIGN KEY (`id_transaksi`) REFERENCES `transaksi` (`id_transaksi`);

--
-- Ketidakleluasaan untuk tabel `perawatan`
--
ALTER TABLE `perawatan`
  ADD CONSTRAINT `perawatan_ibfk_1` FOREIGN KEY (`id_mobil`) REFERENCES `mobil` (`id_mobil`);

--
-- Ketidakleluasaan untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_users`) REFERENCES `users` (`id_users`),
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`id_mobil`) REFERENCES `mobil` (`id_mobil`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
