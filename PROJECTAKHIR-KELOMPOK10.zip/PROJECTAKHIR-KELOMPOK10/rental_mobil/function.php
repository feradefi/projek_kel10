<?php
include 'koneksi.php';

function registrasi($data)
{
    global $conn;
    if ($data['password'] == $data['password2']) {
        $target_dir = "assets/foto/";
        $target_file = $target_dir . basename($_FILES["foto"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Buat folder uploads jika belum ada
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0755, true);
        }

        // Pindahkan file ke direktori target
        if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
            echo "File " . htmlspecialchars(basename($_FILES["foto"]["name"])) . " telah diunggah.";
        } else {
            echo "Maaf, terjadi kesalahan saat mengunggah file Anda.";
        }
        $nama = htmlspecialchars($data['nama']);
        $email = htmlspecialchars($data['email']);
        $no_telepon = htmlspecialchars($data['no_telepon']);
        $username = htmlspecialchars($data['username']);
        $password = htmlspecialchars($data['password']);
        $role   = 'User';
        $alamat = htmlspecialchars($data['alamat']);
        $gambar = $_FILES["foto"]["name"];
        $sql = "INSERT INTO users (nama, email, no_telepon, username, password, role, alamat, gambar) VALUES ('$nama', '$email', '$no_telepon', '$username', '$password', '$role', '$alamat' , '$gambar')";
        mysqli_query($conn, $sql);

        return mysqli_affected_rows($conn);
    } else {
        echo "<script>alert('Password dengan Konfirmasi Password tidak sesuai');";
    }
}
