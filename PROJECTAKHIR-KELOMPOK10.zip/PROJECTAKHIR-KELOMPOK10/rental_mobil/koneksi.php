<?php
$conn = mysqli_connect('localhost', 'root', '', 'rental_mobil');

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
